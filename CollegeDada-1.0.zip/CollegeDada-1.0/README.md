# CollegeDada
Under Science and Technical committee RGIPT , we made an android application . The purpose was to demonstrate how we can (if permitted) bring students transparency about all the college activities including academics, sports, cultural events happening around RGIPT Campus. Then project was also presented in URJOTSAV 2019 - Annual Techfest RGIPT .

This application was meant for learning puposes only. We did not have enough support to continue the project so it was incomplete.
