package com.example.collegedada1;

public class QuizInformation {

    public String Quiz1;
    public String Quiz2;

    public QuizInformation(){

    }

    public QuizInformation(String quiz1, String quiz2) {
        Quiz1 = quiz1;
        Quiz2 = quiz2;
    }
}