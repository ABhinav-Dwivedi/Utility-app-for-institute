package com.example.collegedada1;

public class MarksInformation {

    public String Total;
    public String Obtained ;

    public MarksInformation(){

    }

    public MarksInformation(String total, String obtained){
        Total = total;
        Obtained = obtained;
    }
}
