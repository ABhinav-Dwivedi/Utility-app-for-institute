package com.example.collegedada1;

public class InternalAssessmentInformation {

    public String Project;
    public String LAB;

    public InternalAssessmentInformation(){

    }

    public InternalAssessmentInformation(String project, String lab) {
        Project = project;
        LAB = lab;
    }
}